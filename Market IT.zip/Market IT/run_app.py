import subprocess

if __name__ == "__main__":
    subprocess.call(["streamlit", "run", "MarketIT/cust_seg_app.py"])
